package marvel.francisconeto.com.br.presenter.events;

import android.view.View;
import android.view.View.OnClickListener;

import marvel.francisconeto.com.br.R;
import marvel.francisconeto.com.br.model.ModelBO;
import marvel.francisconeto.com.br.model.json.scheme.JsonCharactersScheme;
import marvel.francisconeto.com.br.presenter.interfaces.IMainPresenter;


public class MainOnClickAction {

    public static class MainAddOnClickAction implements OnClickListener{
		private final transient IMainPresenter presenter;
		
		public MainAddOnClickAction(IMainPresenter presenter){
			this.presenter = presenter;
		}
		
		@Override
		public void onClick(View v) {
            switch (v.getId()){
                case R.id.rel_search:
                    this.presenter.search();
                    break;
                case R.id.rel_back:
                    this.presenter.back();
                    break;
            }

		}
	}
	
	public static class MainLocalOnClickAction implements OnClickListener{
		private final transient IMainPresenter presenter;

		public MainLocalOnClickAction(IMainPresenter presenter){
			this.presenter = presenter;
		}
		
		@Override
		public void onClick(View v) {
//			this.presenter.setLocal(perdidos);
		}
	}

    public static class ItemOnClickActionListener implements OnClickListener {
        private final transient IMainPresenter presenter;
        private final JsonCharactersScheme.Results selectedItem;
        private final int position;

        public ItemOnClickActionListener(final IMainPresenter presenter,
                                         final JsonCharactersScheme.Results selectedItem,
                                         final int position) {
            this.presenter = presenter;
            this.selectedItem = selectedItem;
            this.position = position;
        }



        @Override
        public void onClick(final View view) {
            ModelBO.getInstance().hidKeyboad(view);
            long key = ModelBO.getInstance().setClickable();
            if ( ModelBO.getInstance().isClickable(key)) {
                this.presenter.showDetail(this.selectedItem, this.position);
            }
        }
    }
	

}
