package marvel.francisconeto.com.br.controller;

import android.app.Application;
import android.content.SharedPreferences;

import java.util.HashMap;

import marvel.francisconeto.com.br.controller.utils.LruCacheBitmap;


public class AppApplication extends Application {
	private static AppApplication singleton = null;
	private HashMap<String, Object> attributes = new HashMap<String, Object>();
	private SharedPreferences settings;
	private final String MARVEL_API = "MARVEL_API";
	public static AppApplication getInstance() {
		return singleton;
	}
	
	@Override
	public void onCreate() {
		super.onCreate();

		singleton = this;
		this.settings = getSharedPreferences(MARVEL_API, 0);
		LruCacheBitmap.init(getApplicationContext());
	}
	
	public void setAttributes(HashMap<String, Object> attributes) {
		this.attributes = attributes;
	}

	public HashMap<String, Object> getAttributes() {
		return attributes;
	}
	
	public void put(final String key,final Object value) {
		this.attributes.put(key, value);
	}
	
	public Object get(final String key) {
		return this.attributes.get(key);
	}

	public SharedPreferences getSettings() {
		return settings;
	}

	public void setSettings(SharedPreferences settings) {
		this.settings = settings;
	}
}
