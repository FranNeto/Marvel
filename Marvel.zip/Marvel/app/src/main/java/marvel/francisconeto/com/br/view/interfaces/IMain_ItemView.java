package marvel.francisconeto.com.br.view.interfaces;


import android.view.View;

import marvel.francisconeto.com.br.model.task.DownloadImageFromServerTask;

public interface IMain_ItemView extends DownloadImageFromServerTask.IDownloadImageFromServerTask{
	void setName(String name);
    void setItemOnclickListener(View.OnClickListener listener);
	
	String getName();

}
