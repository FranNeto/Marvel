package marvel.francisconeto.com.br.model.json.scheme;

import java.util.List;

/**
 * Created by FranRose on 08/07/2016.
 */
public class JsonCharactersScheme {

    private int code;
    private String status;
    private String copyright;
    private String attributionText;
    private String attributionHTML;
    private String etag;
    private Data data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCopyright() {
        return copyright;
    }

    public void setCopyright(String copyright) {
        this.copyright = copyright;
    }

    public String getAttributionText() {
        return attributionText;
    }

    public void setAttributionText(String attributionText) {
        this.attributionText = attributionText;
    }

    public String getAttributionHTML() {
        return attributionHTML;
    }

    public void setAttributionHTML(String attributionHTML) {
        this.attributionHTML = attributionHTML;
    }

    public String getEtag() {
        return etag;
    }

    public void setEtag(String etag) {
        this.etag = etag;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public static class Data{
        private int offset;
        private int limit;
        private int total;
        private int count;
        private List<Results> results;

        public int getOffset() {
            return offset;
        }

        public void setOffset(int offset) {
            this.offset = offset;
        }

        public int getLimit() {
            return limit;
        }

        public void setLimit(int limit) {
            this.limit = limit;
        }

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public int getCount() {
            return count;
        }

        public void setCount(int count) {
            this.count = count;
        }

        public List<Results> getResults() {
            return results;
        }

        public void setResults(List<Results> results) {
            this.results = results;
        }
    }

    public static class Results{
        private int id;
        private String name;
        private String description;
        private String modified;
        private String resourceURI;
        private List<Urls> urls;
        private ThumbNail thumbnail;
        private Comics comics;
        private Stories stories;
        private Events events;
        private Series series;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getModified() {
            return modified;
        }

        public void setModified(String modified) {
            this.modified = modified;
        }

        public String getResourceURI() {
            return resourceURI;
        }

        public void setResourceURI(String resourceURI) {
            this.resourceURI = resourceURI;
        }

        public List<Urls> getUrls() {
            return urls;
        }

        public void setUrls(List<Urls> urls) {
            this.urls = urls;
        }

        public ThumbNail getThumbNail() {
            return thumbnail;
        }

        public void setThumbNail(ThumbNail thumbNail) {
            this.thumbnail = thumbNail;
        }

        public Comics getComics() {
            return comics;
        }

        public void setComics(Comics comics) {
            this.comics = comics;
        }

        public Stories getStories() {
            return stories;
        }

        public void setStories(Stories stories) {
            this.stories = stories;
        }

        public Events getEvents() {
            return events;
        }

        public void setEvents(Events events) {
            this.events = events;
        }

        public Series getSeries() {
            return series;
        }

        public void setSeries(Series series) {
            this.series = series;
        }
    }

    public static class Urls{
        private String type;
        private String url;

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }
    }

    public static class ThumbNail{
        private String path;
        private String extension;

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public String getExtension() {
            return extension;
        }

        public void setExtension(String extension) {
            this.extension = extension;
        }
    }

    public static class GenericItems{
        private String resourceURI;
        private String name;

        public String getResourceURI() {
            return resourceURI;
        }

        public void setResourceURI(String resourceURI) {
            this.resourceURI = resourceURI;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    public static class Generic {
        private int available;
        private int returned;
        private String collectionURI;

        public int getAvailable() {
            return available;
        }

        public void setAvailable(int available) {
            this.available = available;
        }

        public int getReturned() {
            return returned;
        }

        public void setReturned(int returned) {
            this.returned = returned;
        }

        public String getCollectionURI() {
            return collectionURI;
        }

        public void setCollectionURI(String collectionURI) {
            this.collectionURI = collectionURI;
        }
    }

    public static class Comics extends Generic{
        private List<GenericItems> items;

        public List<GenericItems> getItems() {
            return items;
        }

        public void setItems(List<GenericItems> items) {
            this.items = items;
        }
    }


    public static class ItemsStories extends GenericItems{
        private String type;

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }
    }

    public static class Stories extends Generic{
        private List<ItemsStories> items;

        public List<ItemsStories> getItems() {
            return items;
        }

        public void setItems(List<ItemsStories> items) {
            this.items = items;
        }
    }

    public static class Events extends Generic{
        private List<GenericItems> items;

        public List<GenericItems> getItems() {
            return items;
        }

        public void setItems(List<GenericItems> items) {
            this.items = items;
        }
    }

    public static class Series extends Generic{
        private List<GenericItems> items;

        public List<GenericItems> getItems() {
            return items;
        }

        public void setItems(List<GenericItems> items) {
            this.items = items;
        }
    }
}
