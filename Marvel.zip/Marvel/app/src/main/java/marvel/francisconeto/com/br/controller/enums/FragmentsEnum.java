package marvel.francisconeto.com.br.controller.enums;


import marvel.francisconeto.com.br.presenter.AbstractPresenter;
import marvel.francisconeto.com.br.presenter.MainPresenter;

public enum FragmentsEnum {

	MAIN(1, MainPresenter.class);

	
	private int framentId;
	private Class<? extends AbstractPresenter> classFrag;
	/**
	 * Constructor
	 */
	private FragmentsEnum(final int framentId, final Class<? extends AbstractPresenter> classFrag) {
		this.framentId = framentId;
		this.classFrag = classFrag;
	}

	public int getFragmentId() {
		return framentId;
	}

	public Class<? extends AbstractPresenter> getClassFrag() {
		return classFrag;
	}
}
