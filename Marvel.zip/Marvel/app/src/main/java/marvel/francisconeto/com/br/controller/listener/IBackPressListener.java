package marvel.francisconeto.com.br.controller.listener;

public interface IBackPressListener {
	
	void onBackPress();
	boolean isAutoRemoveFirstBack();
}