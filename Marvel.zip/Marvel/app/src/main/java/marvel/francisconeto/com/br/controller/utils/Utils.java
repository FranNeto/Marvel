package marvel.francisconeto.com.br.controller.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

import marvel.francisconeto.com.br.R;
import marvel.francisconeto.com.br.controller.AppApplication;
import marvel.francisconeto.com.br.log.WrapperLog;

/**
 * Created by FranRose on 08/07/2016.
 */
public class Utils {

    private static boolean status;

    public static final String MARVEL_CHARACTERS = "MARVEL_CHARACTERS";

    public static void internetChecker(final IInternetConnection listener, final int requestCode) {
        final Context context = AppApplication.getInstance().getApplicationContext();

        ConnectivityManager connManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        if (connManager == null) {
            if (listener != null) {
                status = false;
                listener.isInternetConnected(status,requestCode);
            }
        } else {

            final NetworkInfo netInfo = connManager.getActiveNetworkInfo();

            if (netInfo != null && netInfo.isConnected()) {

                try {

                    final HttpURLConnection urlc = (HttpURLConnection) (new URL(
                            AppApplication.getInstance().getApplicationContext().getResources().getString(R.string.url_base)).openConnection()); //Google ip

                    listener.setLoadingVisibility(true,requestCode);

                    if (urlc != null) {
                        new Thread() {
                            @Override
                            public void run() {
                                urlc.setRequestProperty("User-Agent", "Test");
                                urlc.setRequestProperty("Connection", "close");
                                urlc.setConnectTimeout(10000);
                                urlc.setReadTimeout(10000);

                                try {
                                    urlc.connect();
                                    status = true;//(urlc.getResponseCode() == 200 || urlc.getResponseCode() == 503);
                                    WrapperLog.info("Internet connection: " + status,getClass(),"");

                                } catch (IOException e) {
                                    status = false;
                                    WrapperLog.info("Error on internet connection",getClass(),"");
                                }

                                if (listener != null) {

                                    Handler handler = new Handler(context.getMainLooper());

                                    handler.post(new Runnable() {
                                        @Override
                                        public void run() {

                                            listener.isInternetConnected(status,requestCode);
                                            listener.setLoadingVisibility(false,requestCode);
                                        }
                                    });
                                }
                            }

                        }.start();
                    } else {
                        status = false;
                        if (listener != null) {
                            listener.isInternetConnected(status,requestCode);
                        }
                    }

                } catch (IOException e) {
                    WrapperLog.info("Error on internet connection",Utils.class,"");
                    status = false;
                    if (listener != null) {
                        listener.isInternetConnected(status,requestCode);
                    }
                }

            } else {
                status = false;
                if (listener != null) {
                    listener.isInternetConnected(status,requestCode);
                }
            }
        }

    }

    /**
     * Method to set shared preferences
     *
     * @param key   - key in string
     * @param value - value for set
     */
    public static void putStringSharedPreferences(final String key, final String value) {
        final SharedPreferences sharedPref = AppApplication.getInstance().getSettings();

        final SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString(key, value);
        editor.apply();
    }

    /**
     * Method to get shared preferences
     *
     * @param key - key in string
     * @return String
     */
    public static String getStringSharedPreferences(final String key) {
        final SharedPreferences sharedPref = AppApplication.getInstance().getSettings();
        return sharedPref.getString(key, "");
    }


}
