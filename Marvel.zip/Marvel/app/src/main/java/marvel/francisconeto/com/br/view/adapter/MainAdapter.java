package marvel.francisconeto.com.br.view.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import java.util.ArrayList;
import java.util.List;

import marvel.francisconeto.com.br.R;
import marvel.francisconeto.com.br.log.WrapperLog;
import marvel.francisconeto.com.br.model.task.FlyWeightImageFactory;
import marvel.francisconeto.com.br.model.json.scheme.JsonCharactersScheme;
import marvel.francisconeto.com.br.presenter.events.MainOnClickAction;
import marvel.francisconeto.com.br.presenter.interfaces.IMainPresenter;
import marvel.francisconeto.com.br.view.Main_ItemView;
import marvel.francisconeto.com.br.view.interfaces.IMain_ItemView;


public class MainAdapter extends BaseAdapter{
	private transient IMainPresenter presenter;
	private transient List<JsonCharactersScheme.Results> listcharacters;
	
	public MainAdapter(final IMainPresenter presenter){
		this.presenter = presenter;
        this.listcharacters = new ArrayList<JsonCharactersScheme.Results>();
	}
	
	@Override
	public int getCount() {
        WrapperLog.info("ListAdapter_getCount: "+this.listcharacters.size(),getClass(),"");
		return listcharacters.size();
	}

	@Override
	public Object getItem(int position) {
		return listcharacters.get(position);
	}

	@Override
	public long getItemId(int position) {
		return (long)position;
	}
	
	public void update(List<JsonCharactersScheme.Results> list){
		this.listcharacters = list;
        WrapperLog.info("ListAdapter_update: "+this.listcharacters.size(),getClass(),"");
		notifyDataSetChanged();
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
        JsonCharactersScheme.Results characters = (JsonCharactersScheme.Results) this.getItem(position);

		final ViewGroup view = (ViewGroup) LayoutInflater.from(parent.getContext()).inflate(R.layout.item_main, null);
		
		IMain_ItemView main = new Main_ItemView(view);
		main.setName(characters.getName());
        if(characters.getThumbNail() != null && characters.getThumbNail().getPath().toString() != null && characters.getThumbNail().getExtension().toString() != null){
            String thumbnail = characters.getThumbNail().getPath()+"."+characters.getThumbNail().getExtension();
            FlyWeightImageFactory.getInstance().getImage(thumbnail,main);
        }

        main.setItemOnclickListener(new MainOnClickAction.ItemOnClickActionListener(presenter, (JsonCharactersScheme.Results) this.getItem(position), position));

        WrapperLog.info("ListAdapter_Name: "+characters.getThumbNail().getPath(),getClass(),"");

		
		return view;
	}

}
