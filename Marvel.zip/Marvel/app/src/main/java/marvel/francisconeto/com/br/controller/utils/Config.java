package marvel.francisconeto.com.br.controller.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Created by FranRose on 08/07/2016.
 */
public class Config {
    public static final String PUBLIC_KEY = "33f5de44c47502817c9f16e3a55682b4";
    public static final String PRIVATE_KEY = "8797c3c5d6df89a56e2c7f4f7cbf06a603972d32";

    public static final String BASE_URL  = "http://gateway.marvel.com/";
    public static final String CHARACTERS = BASE_URL+"v1/public/characters";
    public static final String TIMESTAMP = "ts";
    public static final String API_KEY = "apikey";
    public static final String HASH = "hash";

    private static char[] HEXCHARS = {'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'};

    public static String md5(String s) {
        try {
            // Create MD5 Hash
            MessageDigest digest = java.security.MessageDigest.getInstance("MD5");
            digest.update(s.getBytes());
            String hash = new String(hexEncode(digest.digest()));

            return hash;

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }

    public static String hexEncode(byte[] bytes) {
        char[] result = new char[bytes.length*2];
        int b;
        for (int i = 0, j = 0; i < bytes.length; i++) {
            b = bytes[i] & 0xff;
            result[j++] = HEXCHARS[b >> 4];
            result[j++] = HEXCHARS[b & 0xf];
        }
        return new String(result);
    }

}
