package marvel.francisconeto.com.br.view.interfaces;

import android.view.View.OnClickListener;
import android.widget.BaseAdapter;

import marvel.francisconeto.com.br.model.task.DownloadImageFromServerTask;


public interface IMainView extends DownloadImageFromServerTask.IDownloadImageFromServerTask{
	void setAddOnClickListener(OnClickListener listener);
    void setMainAdapter(BaseAdapter mainAdapter);
    void setVisibleDetail(int visible);

    void setTitleDetail(String title);
    void setDescriptionDetail(String title);

    String getTitleDetail();
    String getDescriptionDetail();

    boolean isVisibleDetail();
}
