package marvel.francisconeto.com.br.controller.utils;

import android.support.v4.app.FragmentActivity;

import marvel.francisconeto.com.br.controller.enums.ActionEnum;
import marvel.francisconeto.com.br.controller.enums.FragmentsEnum;


interface IFragmentBuilderController {
	void setActivity(FragmentActivity activity);
	void setContentId(final int contId);
	void setAction(final ActionEnum action);
	void setFragmentId(final FragmentsEnum frament);
	void show();
	void removeLastFragment();
}
