package marvel.francisconeto.com.br.controller.utils;

/**
 * Created by FranRose on 08/07/2016.
 */
public interface IInternetConnection {
    void isInternetConnected(boolean status, int requestCode);
    void setLoadingVisibility(boolean visible, int requestCode);
}
