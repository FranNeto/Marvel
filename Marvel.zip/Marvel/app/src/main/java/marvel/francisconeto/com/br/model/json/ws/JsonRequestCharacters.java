package marvel.francisconeto.com.br.model.json.ws;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import java.util.List;

import cz.msebera.android.httpclient.Header;
import marvel.francisconeto.com.br.controller.utils.Utils;
import marvel.francisconeto.com.br.log.WrapperLog;
import marvel.francisconeto.com.br.model.json.scheme.JsonCharactersScheme;
import marvel.francisconeto.com.br.model.json.scheme.JsonStatusScheme;

/**
 * Created by FranRose on 08/07/2016.
 */
public class JsonRequestCharacters {
    public interface IJsonRequestCharacters {
        void onSuccess(List<JsonCharactersScheme.Results> charactersList);
        void onFailure(String msg);

    }

    public static void execute(final String url,final IJsonRequestCharacters listener) {
        final Gson gson = new Gson();
        WrapperLog.info("url_Characters: " + url,JsonRequestCharacters.class,"");
        AsyncHttpClient client = new AsyncHttpClient();

        client.get(url, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody){
                try {
                    JsonStatusScheme result = gson.fromJson(new String(responseBody), JsonStatusScheme.class);
                    if (result.getCode().equals("200")) {
                        JsonCharactersScheme sucessJSON = gson.fromJson(new String(responseBody),JsonCharactersScheme.class);
                        WrapperLog.info("Json onSuccess:" +gson.toJson(sucessJSON), getClass(), "");
                        Utils.putStringSharedPreferences(Utils.MARVEL_CHARACTERS, new String(responseBody));
//
                        listener.onSuccess(sucessJSON.getData().getResults());

                    }else{
//                            listener.onFailure(result.getMessage());
                        WrapperLog.info("Json onSuccess else: " + result.getMessage(), getClass(), "");

                    }
                } catch (JsonParseException e) {
                      WrapperLog.info("Json JsonParseException: " + e.getMessage(), getClass(), "");
//                    listener.onFailure("Erro de conexão com o servidor.");
                }
            }

            @Override
            public void onFailure(int i, Header[] headers, byte[] bytes, Throwable throwable) {
                WrapperLog.info("Json onFailure: " + throwable.getMessage(), getClass(), "");
//                listener.onFailure("Erro de conexão com o servidor.");
            }
        });
    }
}
