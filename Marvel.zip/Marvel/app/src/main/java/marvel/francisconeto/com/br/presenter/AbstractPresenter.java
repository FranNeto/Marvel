package marvel.francisconeto.com.br.presenter;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;

public abstract class AbstractPresenter extends Fragment {
	protected InputMethodManager imm;
	public void createView(final ViewGroup view){
		this.setUpListeners();
	}
	
	public abstract void setUpListeners();

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		imm =  (InputMethodManager) getActivity().getSystemService(getActivity().INPUT_METHOD_SERVICE);
		getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
	}
}
