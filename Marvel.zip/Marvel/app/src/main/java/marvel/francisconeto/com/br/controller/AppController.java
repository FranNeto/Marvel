package marvel.francisconeto.com.br.controller;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

import com.google.gson.Gson;

import marvel.francisconeto.com.br.controller.enums.FragmentsEnum;
import marvel.francisconeto.com.br.controller.utils.DisplayUtil;
import marvel.francisconeto.com.br.controller.utils.FragmentBuilder;
import marvel.francisconeto.com.br.controller.utils.Utils;
import marvel.francisconeto.com.br.model.json.ws.JsonRequestCharacters;


public class AppController extends FragmentActivity {
	private static AppController instance;
	private static final String FRAGMENT_SIZE = "fragment_size";
	public static FragmentsEnum SELECTED_SCREEN;
	private static final Object SYNCOBJECT = new Object();
	

	@Override
	protected void onCreate(final Bundle bundle) {
		super.onCreate(bundle);
		DisplayUtil.init(this);

        this.restoreData();
				
		if (bundle == null) {
			FragmentBuilder.addFragment(this, android.R.id.content, FragmentsEnum.MAIN);
		} else {
			final int size = bundle.getInt(FRAGMENT_SIZE);
			FragmentBuilder.getInstance().setSize(size);
		}
		
	}
	
	public static AppController getInstance() {
		synchronized (SYNCOBJECT) {
			if (instance == null) {
				instance = new AppController();
			}
		}
		return instance;
	}

    public void restoreData() {
        if(!Utils.getStringSharedPreferences(Utils.MARVEL_CHARACTERS).equals("")){
            final Gson gson = new Gson();
            String characters =  Utils.getStringSharedPreferences(Utils.MARVEL_CHARACTERS);
            JsonRequestCharacters sucessJson = gson.fromJson(characters, JsonRequestCharacters.class);

        }
    }


    @Override
	protected void onSaveInstanceState(Bundle outState) {
		outState.putInt(FRAGMENT_SIZE, FragmentBuilder.getInstance().getSize());
		super.onSaveInstanceState(outState);
	}
}