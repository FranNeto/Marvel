package marvel.francisconeto.com.br.view;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import marvel.francisconeto.com.br.R;
import marvel.francisconeto.com.br.controller.utils.DisplayUtil;
import marvel.francisconeto.com.br.controller.utils.LruCacheBitmap;
import marvel.francisconeto.com.br.view.interfaces.IMainView;


@SuppressLint("NewApi")
public class MainView implements IMainView {
	private transient TextView txt_titulo;
	private transient ListView list_view;
	private transient RelativeLayout relSearch;

    private transient RelativeLayout relBack;
    private transient View relativeDetail;
	private transient ImageView imgDetail;
    private transient TextView titleDetail;
    private transient TextView description;

	

	public MainView(ViewGroup view){
		DisplayUtil.setLayoutParams(view);
		setTxtTitulo(view);
		setListView(view);
		setRelAdd(view);
		setTitleDetail(view);
        setImgDetail(view);
        setDescription(view);
        setRelDetail(view);
        setRelBack(view);
    }

	private void setTxtTitulo(ViewGroup view){
		View titulo = view.findViewById(R.id.txt_titulo_main);
		if(titulo != null && titulo instanceof TextView){
			txt_titulo = (TextView) titulo;
		}
	}

    private void setTitleDetail(ViewGroup view){
        View titulo = view.findViewById(R.id.text_title_detail);
        if(titulo != null && titulo instanceof TextView){
            titleDetail = (TextView) titulo;
        }
    }

    private void setDescription(ViewGroup view){
        View desc = view.findViewById(R.id.text_description);
        if(desc != null && desc instanceof TextView){
            description = (TextView) desc;
        }
    }

    private void setImgDetail(ViewGroup view){
        View img = view.findViewById(R.id.img_detail);
        if(img != null && img instanceof ImageView){
            imgDetail = (ImageView) img;
        }
    }

    private void setRelBack(ViewGroup view){
        View back = view.findViewById(R.id.rel_back);
        if(back != null && back instanceof RelativeLayout){
            relBack = (RelativeLayout) back;
        }
    }

    private void setRelDetail(ViewGroup view){
        View viewDetail = view.findViewById(R.id.relative_detail);
        if(viewDetail != null && viewDetail instanceof View){
            relativeDetail = (View) viewDetail;
            ObjectAnimator anim = ObjectAnimator.ofFloat(viewDetail,
                    "translationY", -500f, 0f);
            anim.setDuration(2000);
            anim.start();
        }
    }

	
	private void setListView(ViewGroup view){
		View list = view.findViewById(R.id.listCharacters);
		if(list != null && list instanceof ListView){
			list_view = (ListView) list;
		}
	}
	
	private void setRelAdd(ViewGroup view){
		View rel = view.findViewById(R.id.rel_search);
		if(rel != null && rel instanceof RelativeLayout){
            relSearch = (RelativeLayout) rel;
		}
	}
	

	@Override
	public void setAddOnClickListener(OnClickListener listener) {

        relSearch.setOnClickListener(listener);
        relativeDetail.setOnClickListener(listener);
        relBack.setOnClickListener(listener);

	}



    @Override
    public void setMainAdapter(BaseAdapter mainAdapter) {
            list_view.setAdapter(mainAdapter);

    }

    @Override
    public void setVisibleDetail(int visible) {
        this.relativeDetail.setVisibility(visible);

    }

    @Override
    public void setTitleDetail(String title) {
        if(titleDetail != null){
            titleDetail.setText(title);
        }
    }

    @Override
    public void setDescriptionDetail(String title) {
        if(description != null){
            description.setText(title);
        }
    }

    @Override
    public String getTitleDetail() {
        return titleDetail == null?"":String.valueOf(titleDetail.getText());
    }

    @Override
    public String getDescriptionDetail() {
        return description == null?"":String.valueOf(description.getText());
    }

    @Override
    public boolean isVisibleDetail() {
        return relativeDetail.getVisibility() == View.VISIBLE;
    }


    @Override
    public void showDialog() {

    }

    @Override
    public void dismissDialog() {

    }

    @Override
    public void setImage(Bitmap bitmap) {
        imgDetail.setBackground(LruCacheBitmap.convertBitmapToDrawable(list_view.getContext(), bitmap));
    }

    @Override
    public void setStandardImage() {

    }
}
