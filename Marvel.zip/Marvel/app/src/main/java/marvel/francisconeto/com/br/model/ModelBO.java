package marvel.francisconeto.com.br.model;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;

import android.os.Handler;
import android.os.Vibrator;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;


import marvel.francisconeto.com.br.controller.enums.FragmentsEnum;
import marvel.francisconeto.com.br.controller.utils.DisplayUtil;


public class ModelBO {

	private static ModelBO instance = null;
	private static final Object SYNCOBJECT = new Object();
    private boolean isClickable = true;
    private long clickLockKey = 0;
    public static FragmentsEnum SELECTED_SCREEN;


	public static ModelBO getInstance() {
		synchronized (SYNCOBJECT) {
			if (instance == null) {
				instance = new ModelBO();
			}
		}
		return instance;
	}

	public void hidKeyboad(final View view) {
		InputMethodManager imm = (InputMethodManager) view.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.hideSoftInputFromWindow(view.getApplicationWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
	}

    synchronized public boolean isClickable(long time) {
        return (time == clickLockKey);
    }

    synchronized public long setClickable() {
        if ( isClickable ) {
            isClickable = false;
            clickLockKey = System.currentTimeMillis() + 500;
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    isClickable = true;
                }
            }, 500);

            return clickLockKey;
        }

        return 0;
    }


    public void vibrate(final Context context) {
		Vibrator v = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
		v.vibrate(100);
	}


	public void animateView(final ViewGroup view, final String property, final int duration) {
		final boolean isOpening = View.GONE == view.getVisibility();
		int size = getSize(view, property);
		final float start = isOpening ? size : 0;
		final float end = isOpening ? 0 : size;

		ObjectAnimator animator = ObjectAnimator.ofFloat(view, property, start, end);
		animator.addListener(new AnimatorListener() {

			@Override
			public void onAnimationStart(Animator animation) {
				if ( isOpening ) {
					view.setVisibility(View.VISIBLE);
				}
			}

			@Override
			public void onAnimationRepeat(Animator animation) {}

			@Override
			public void onAnimationEnd(Animator animation) {
				if ( !isOpening ) {
					view.setVisibility(View.GONE);
				}
			}

			@Override
			public void onAnimationCancel(Animator animation) {}
		});
		animator.setDuration(duration);
		animator.start();
	}

	public void animateView(final ViewGroup view, final String property, final int duration, final float startAxisPosition, final float finalAxisPosition) {
		final float start = startAxisPosition;
		final float end = finalAxisPosition;

		ObjectAnimator animator = ObjectAnimator.ofFloat(view, property, start, end);
		animator.setDuration(duration);
		animator.start();
	}

	private int getSize(ViewGroup view, String property) {
		int size = 0;
		if ( property.equals("translationX") ) {
			size = view.getWidth();
		} else if (property.equals("translationY")) {
			size = view.getHeight();
		}

		return size;
	}

	public void transitionTranslateRightX(final View view, final boolean showTab, final int duration) {
		float startY, endY;
		if (showTab) {
			startY = DisplayUtil.getWidthScreen();
			endY = 0;
		} else {
			startY = 0;
			endY = DisplayUtil.getWidthScreen();
		}

		ObjectAnimator animator = ObjectAnimator.ofFloat(view, View.TRANSLATION_X, startY, endY);
		animator.addListener(new AnimatorListener() {

			@Override
			public void onAnimationStart(Animator animation) {
				if (showTab) {
					view.setVisibility(View.VISIBLE);
				}
			}

			@Override
			public void onAnimationRepeat(Animator animation) {

			}

			@Override
			public void onAnimationEnd(Animator animation) {
				if (!showTab) {
					view.setVisibility(View.GONE);
				}
			}

			@Override
			public void onAnimationCancel(Animator animation) {
			}
		});
		animator.setDuration(duration);
		animator.start();
	}


	public void transitionY(final View view, final boolean showTab ,  final int duration) {
		float startY, endY;
		if (showTab) {
			startY = DisplayUtil.getHeightScreenNoStatusBar();
			endY = 0;
		} else {
			startY = 0;
			endY = DisplayUtil.getHeightScreenNoStatusBar();
		}

		ObjectAnimator animator = ObjectAnimator.ofFloat(view, View.TRANSLATION_Y, startY, endY);
		animator.addListener(new AnimatorListener() {

			@Override
			public void onAnimationStart(Animator animation) {
				if (showTab) {
					view.setVisibility(View.VISIBLE);
				}
			}

			@Override
			public void onAnimationRepeat(Animator animation) {

			}

			@Override
			public void onAnimationEnd(Animator animation) {
				if (!showTab) {
					view.setVisibility(View.GONE);
				}
			}

			@Override
			public void onAnimationCancel(Animator animation) {
			}
		});
		animator.setDuration(duration);
		animator.start();
	}

	public void transitionZoom(final View view, final boolean showTab ,  final int duration) {
		float start, end;
		if (showTab) {
			start = 0;
			end   = 1;
		} else {
			start = 1;
			end  = 0;
		}

		ObjectAnimator scaleDownX = ObjectAnimator.ofFloat(view, View.SCALE_X, start, end);
        ObjectAnimator scaleDownY = ObjectAnimator.ofFloat(view, View.SCALE_Y, start, end);
        AnimatorSet scaleDown = new AnimatorSet();
        scaleDown.play(scaleDownX).with(scaleDownY);
		
        scaleDown.addListener(new AnimatorListener() {

			@Override
			public void onAnimationStart(Animator animation) {
				if (showTab) {
					view.setVisibility(View.VISIBLE);
				}
			}

			@Override
			public void onAnimationRepeat(Animator animation) {

			}

			@Override
			public void onAnimationEnd(Animator animation) {
				if (!showTab) {
					view.setVisibility(View.GONE);
				}
			}

			@Override
			public void onAnimationCancel(Animator animation) {
			}
		});
        scaleDown.setDuration(duration);
        scaleDown.start();
	}



}
