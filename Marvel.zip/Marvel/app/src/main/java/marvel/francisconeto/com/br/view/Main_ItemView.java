package marvel.francisconeto.com.br.view;


import android.graphics.Bitmap;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import marvel.francisconeto.com.br.R;
import marvel.francisconeto.com.br.controller.utils.DisplayUtil;
import marvel.francisconeto.com.br.controller.utils.LruCacheBitmap;
import marvel.francisconeto.com.br.view.interfaces.IMain_ItemView;

public class Main_ItemView implements IMain_ItemView {
	private transient TextView txt_name;
	private transient View imgCharacters;
    private View view;

	public Main_ItemView(ViewGroup view){
		DisplayUtil.setLayoutParams(view);
        this.view = view;
		setTxtName(view);
		setImg(view);
	}
	
	private void setTxtName(ViewGroup view){
		View name = view.findViewById(R.id.txt_item_name);
		if(name != null && name instanceof TextView){
			txt_name = (TextView) name;
		}
	}

	private void setImg(ViewGroup view){
		View img = view.findViewById(R.id.imgCharacters);
		if(img != null && img instanceof View){
			this.imgCharacters = (View) img;
		}
	}

	@Override
	public void setName(String name) {
		if(txt_name != null){
			txt_name.setText(name);
		}
	}

    @Override
    public void setItemOnclickListener(View.OnClickListener listener) {
        this.view.setOnClickListener(listener);
    }


    @Override
	public String getName() {
		return txt_name == null?"":String.valueOf(txt_name.getText());
	}


    @Override
    public void showDialog() {

    }

    @Override
    public void dismissDialog() {

    }

    @Override
    public void setImage(Bitmap bitmap) {
        this.imgCharacters.setBackground(LruCacheBitmap.convertBitmapToDrawable(this.view.getContext(), bitmap));
    }

    @Override
    public void setStandardImage() {

    }

}
