
package marvel.francisconeto.com.br.log;

import android.util.Log;

/**
 * Class Represents a Wrapper DesignPattern in Log, we should use instead to
 * Android Native Log.
 */
public final class WrapperLog {

    private static boolean LOG_ENABLE = true;
    private static String LOG_TAG = "MARVEL_API";

    public static void initDebug(boolean logEnable, String logTag){
        WrapperLog.LOG_ENABLE = logEnable;
        WrapperLog.LOG_TAG = logTag;
    }

    public static boolean isDebug(){
        return WrapperLog.LOG_ENABLE;
    }

    /**
     * Send a DEBUG log message.
     * @param msg
     * @param className
     * @param classMethod
     */
    public static void debug(String msg, Class<?> className, String classMethod) {
        if (LOG_ENABLE) {
            Log.d(LOG_TAG, "[" + className.getSimpleName() + "." + classMethod + "] " + msg);
        }
    }

    /**
     * Send an INFO log message.
     * @param msg
     * @param className
     * @param classMethod
     */
    public static void info(String msg, Class<?> className, String classMethod) {
        if (LOG_ENABLE) {
            Log.i(LOG_TAG, "[" + className.getSimpleName() + "." + classMethod + "] " + msg);
        }
    }

    /**
     * Send an ERROR log message.
     * @param msg
     * @param className
     * @param classMethod
     */
    public static void error(String msg, Class<?> className, String classMethod) {
        if (LOG_ENABLE) {
            Log.e(LOG_TAG, "[" + className.getSimpleName() + "." + classMethod + "] " + msg);
        }
    }

	/**
	* Send an ERROR log message.
	* @param msg
	* @param className
	* @param classMethod
	*/
	public static void error(String msg, Class<?> className, String classMethod, Throwable throwable) {
		if (LOG_ENABLE) {
			Log.e(LOG_TAG, "[" + className.getSimpleName() + "." + classMethod + "] " + msg, throwable);
		}
	}

    /**
     * Send a WARN log message.
     * @param msg
     * @param className
     * @param classMethod
     */
    public static void warning(String msg, Class<?> className, String classMethod) {
        if (LOG_ENABLE) {
            Log.w(LOG_TAG, "[" + className.getSimpleName() + "." + classMethod + "] " + msg);
        }
    }
}
