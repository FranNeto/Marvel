package marvel.francisconeto.com.br.presenter.interfaces;

import android.app.Activity;

import marvel.francisconeto.com.br.model.json.scheme.JsonCharactersScheme;


public interface IMainPresenter {
	void search();
    void back();
    void showDetail(JsonCharactersScheme.Results selectedItem, int position);
	Activity getLocalActivity();
}
