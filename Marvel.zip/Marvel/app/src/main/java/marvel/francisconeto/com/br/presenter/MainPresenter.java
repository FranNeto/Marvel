package marvel.francisconeto.com.br.presenter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import marvel.francisconeto.com.br.R;
import marvel.francisconeto.com.br.controller.utils.Config;
import marvel.francisconeto.com.br.log.WrapperLog;
import marvel.francisconeto.com.br.model.json.scheme.JsonCharactersScheme;
import marvel.francisconeto.com.br.model.json.ws.JsonRequestCharacters;
import marvel.francisconeto.com.br.model.task.DownloadImageFromServerTask;
import marvel.francisconeto.com.br.presenter.events.MainOnClickAction;
import marvel.francisconeto.com.br.presenter.interfaces.IMainPresenter;
import marvel.francisconeto.com.br.view.MainView;
import marvel.francisconeto.com.br.view.adapter.MainAdapter;
import marvel.francisconeto.com.br.view.interfaces.IMainView;

@SuppressLint("NewApi")
public class MainPresenter extends AbstractPresenter implements IMainPresenter, JsonRequestCharacters.IJsonRequestCharacters {

	private transient IMainView view;
	private transient FragmentActivity activity;
	private transient MainAdapter adapter;

	private transient ProgressDialog progressDialog;
	
	private List<JsonCharactersScheme> listCharacters = new ArrayList<JsonCharactersScheme>();
	private SimpleDateFormat FORMATTER =  new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
	
	@Override
	public void onAttach(Activity activity) {
		this.activity = (FragmentActivity) activity;
		super.onAttach(activity);
		
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		final ViewGroup view = (ViewGroup)inflater.inflate(R.layout.main, container, false);
		createView(view);
		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
        String ts = Long.toString(System.currentTimeMillis()/1000);
        String apiKey = Config.PUBLIC_KEY;
        String hash = Config.md5(ts+Config.PRIVATE_KEY+apiKey);

        String url = Config.CHARACTERS+"?"+Config.TIMESTAMP+"="+ts+"&"+Config.API_KEY+"="+apiKey+"&"+Config.HASH+"="+hash;

        JsonRequestCharacters.execute(url,this);
	}

	@Override
	public void createView(ViewGroup view) {
		this.view = new MainView(view);
		adapter = new MainAdapter(this);
		this.view.setMainAdapter(adapter);
		super.createView(view);
		
	}
	
	@Override
	public void setUpListeners() {
		this.view.setAddOnClickListener(new MainOnClickAction.MainAddOnClickAction(this));
	}

	@Override
	public void search() {
		Toast.makeText(getActivity(),"Em Desenvolvimento",Toast.LENGTH_SHORT).show();
	}

    @Override
    public void back() {
        if(view.isVisibleDetail()){
            view.setVisibleDetail(View.GONE);
        }

    }

    @Override
    public void showDetail(JsonCharactersScheme.Results selectedItem, int position) {
        view.setVisibleDetail(View.VISIBLE);
        String img = selectedItem.getThumbNail().getPath()+"."+selectedItem.getThumbNail().getExtension();
        new DownloadImageFromServerTask(this.view).execute(img);
        view.setTitleDetail(selectedItem.getName());
        view.setDescriptionDetail(selectedItem.getDescription());

    }

    @Override
	public Activity getLocalActivity() {
		return activity;
	}



    @Override
    public void onSuccess(List<JsonCharactersScheme.Results> charactersList) {
        adapter.update(charactersList);
        this.view.setMainAdapter(adapter);

    }

    @Override
    public void onFailure(String msg) {
        Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
    }
}
