package marvel.francisconeto.com.br.model.task;

import android.graphics.Bitmap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import marvel.francisconeto.com.br.controller.utils.LruCacheBitmap;
import marvel.francisconeto.com.br.log.WrapperLog;


public class FlyWeightImageFactory {
    private HashMap<String, IFlyWeightImage> imageList = new HashMap<String, IFlyWeightImage>();
    private static FlyWeightImageFactory instance = null;
    private static final Object SYNCOBJECT = new Object();

    public static FlyWeightImageFactory getInstance() {
        synchronized (SYNCOBJECT) {
            if (instance == null) {
                instance = new FlyWeightImageFactory();
            }
        }
        return instance;
    }

    public void getImage(String image, DownloadImageFromServerTask.IDownloadImageFromServerTask listener) {
        Bitmap bitmap = LruCacheBitmap.getBitmapFromMemoryCache(image);
        if (bitmap == null) {
            listener.setStandardImage();
            if (imageList.get(image) == null) {
                this.addImage(image, listener);
            } else {
                imageList.get(image).addObserver(listener);
                WrapperLog.info("FlyWeight:addImage:1:" + imageList.get(image).isFinished(),getClass(),"");
                if (imageList.get(image).isFinished()) {
                    imageList.get(image).updateImage();
                }
            }
        } else {
            listener.dismissDialog();
            listener.setImage(bitmap);
        }
    }

    public void addImage(String image, DownloadImageFromServerTask.IDownloadImageFromServerTask listener) {
        Bitmap bitmap = LruCacheBitmap.getBitmapFromMemoryCache(image);
        if (bitmap == null) {
            if (imageList.get(image) == null) {
                imageList.put(image, new FlyWeightImage(image, listener));
            } else {
                imageList.get(image).addObserver(listener);
                if (imageList.get(image).isFinished()) {
                    imageList.get(image).updateImage();
                    imageList.get(image).dismissDialog();
                }
            }
        } else {
            imageList.get(image).setImage(bitmap);
        }
    }


    public interface IFlyWeightImage extends  DownloadImageFromServerTask.IDownloadImageFromServerTask {
        void updateImage();

        void addObserver(DownloadImageFromServerTask.IDownloadImageFromServerTask observer);

        boolean isFinished();
    }

    public class FlyWeightImage implements IFlyWeightImage {
        private final String image;
        private boolean isFinished;
        List<DownloadImageFromServerTask.IDownloadImageFromServerTask> observerList;

        public FlyWeightImage(String image, DownloadImageFromServerTask.IDownloadImageFromServerTask observer) {
            this.image = image;
            this.observerList = new ArrayList<DownloadImageFromServerTask.IDownloadImageFromServerTask>();
            this.observerList.add(observer);
            new DownloadImageFromServerTask(this).execute(image);
        }

        @Override
        public void updateImage() {
            Bitmap bitmap = LruCacheBitmap.getBitmapFromMemoryCache(image);
            for (DownloadImageFromServerTask.IDownloadImageFromServerTask view : this.observerList) {
                view.dismissDialog();
                if (bitmap == null) {
                    view.setStandardImage();
                }else{
                    view.setImage(bitmap);
                }
            }
        }

        @Override
        public void addObserver(DownloadImageFromServerTask.IDownloadImageFromServerTask observer) {
            observerList.add(observer);
        }

        @Override
        public void showDialog() {

        }

        @Override
        public void dismissDialog() {

        }

        @Override
        public void setImage(Bitmap bitmap) {
            for (DownloadImageFromServerTask.IDownloadImageFromServerTask view : this.observerList) {
                view.dismissDialog();
                if (bitmap == null) {
                    view.setStandardImage();
                }else{
                    view.setImage(bitmap);
                }
            }
            isFinished = true;
        }

        @Override
        public void setStandardImage() {
            for (DownloadImageFromServerTask.IDownloadImageFromServerTask view : this.observerList) {
                view.dismissDialog();
                view.setStandardImage();
            }
            isFinished = true;
        }


        @Override
        public boolean isFinished() {
            return isFinished;
        }
    }
}
