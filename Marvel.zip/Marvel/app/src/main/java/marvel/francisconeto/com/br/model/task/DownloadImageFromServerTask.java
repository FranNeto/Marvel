package marvel.francisconeto.com.br.model.task;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

import java.io.InputStream;

import marvel.francisconeto.com.br.controller.utils.LruCacheBitmap;
import marvel.francisconeto.com.br.log.WrapperLog;


public class DownloadImageFromServerTask extends AsyncTask<String, Void, Bitmap> {

    private IDownloadImageFromServerTask listener;

    private String error;

    public interface IDownloadImageFromServerTask {

        void showDialog();

        void dismissDialog();

        void setImage(Bitmap bitmap);

        void setStandardImage();

    }

    public DownloadImageFromServerTask(IDownloadImageFromServerTask presenter) {
        this.listener = presenter;
    }

    @Override
    protected void onPreExecute() {
        this.listener.showDialog();
        super.onPreExecute();
    }

    protected Bitmap doInBackground(String... urls) {
        String url = urls[0];
        Bitmap bitmap = null;
        try {
            bitmap = LruCacheBitmap.getBitmapFromMemoryCache(url);


            WrapperLog.info("url:" + url + " bitmap " + bitmap,getClass(),"");
            if (bitmap == null) {
                InputStream in = new java.net.URL(url).openStream();
                bitmap = BitmapFactory.decodeStream(in);
                LruCacheBitmap.addBitmapToMemoryCache(url, bitmap);
            }
        } catch (Exception e) {
            this.error = "Error de conexão com o servidor.";
            WrapperLog.info("Error_Download:" + e.getMessage()+" / "+this.error,getClass(),"");
        }
        return bitmap;
    }

    protected void onPostExecute(Bitmap bitmap) {
        if(bitmap==null) {
            this.listener.setStandardImage();
        }else{
            this.listener.setImage(bitmap);
        }

        this.listener.dismissDialog();
    }
}
